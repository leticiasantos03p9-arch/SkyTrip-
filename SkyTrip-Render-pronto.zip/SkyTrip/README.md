# SkyTrip ✈️

Aplicação web responsiva de planejamento de viagens com frontend HTML/CSS/JavaScript, backend Java Spring Boot e banco H2.

## Publicar no Render pelo celular

1. Crie uma conta em https://github.com/signup.
2. No GitHub, crie um repositório novo chamado `skytrip` (pode ser público).
3. Envie os arquivos e pastas desta pasta para o repositório. Extraia o ZIP antes de enviar; envie o conteúdo da pasta `SkyTrip`, incluindo `Dockerfile`, `.dockerignore`, `render.yaml`, `pom.xml` e `src`.
4. Acesse https://render.com e entre com GitHub.
5. Escolha **New + → Blueprint** (se disponível) e selecione o repositório `skytrip`; ou crie **New + → Web Service**, conecte o repositório e escolha **Docker** como ambiente.
6. Inicie a publicação e aguarde o build. O Render mostrará um endereço público `https://...onrender.com`.

## Banco de dados

Para manter as viagens após reinicializações, configure um disco persistente no serviço Render com o caminho de montagem `/var/data`. O arquivo H2 usa `SKYTRIP_DB_PATH=/var/data/skytripdb`. Sem disco persistente, os dados podem ser apagados quando a instância reiniciar ou for recriada. O plano gratuito pode ter limitações e suspensão por inatividade.

## Executar localmente

Requer Java 17+ e Maven 3.8+:

```bash
mvn spring-boot:run
```

Abra `http://localhost:8080`.

## Limitações atuais

- Esta é uma aplicação web responsiva, não um APK Android.
- Não há login nem separação de viagens por pessoa: quem acessar a mesma instância pode ver as viagens cadastradas.
- Para uso real por várias pessoas, recomenda-se PostgreSQL e autenticação individual.
- Não deixe o console H2 exposto em produção.
