import com.sun.net.httpserver.*;
import java.io.*; import java.net.InetSocketAddress; import java.nio.file.*;

// Servidor SkyTrip: serve o site (pasta public) e salva viagens em viagens.json
// Compilar: javac SkyTripServer.java   Rodar: java SkyTripServer   Abrir: http://localhost:8080
public class SkyTripServer {
  static Path DATA = Paths.get("viagens.json");
  public static void main(String[] a) throws Exception {
    int port = Integer.parseInt(System.getenv().getOrDefault("PORT", "8080"));
    HttpServer s = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
    s.createContext("/api/viagens", ex -> {
      ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
      ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET,PUT,OPTIONS");
      ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
      String m = ex.getRequestMethod(); byte[] out;
      if (m.equals("PUT")) { byte[] body = ex.getRequestBody().readAllBytes(); Files.write(DATA, body); out = "{\"ok\":true}".getBytes(); }
      else if (m.equals("OPTIONS")) out = new byte[0];
      else out = Files.exists(DATA) ? Files.readAllBytes(DATA) : "[]".getBytes();
      ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
      ex.sendResponseHeaders(200, out.length == 0 ? -1 : out.length);
      if (out.length > 0) try (OutputStream o = ex.getResponseBody()) { o.write(out); }
      ex.close();
    });
    s.createContext("/", ex -> {
      String p = ex.getRequestURI().getPath(); if (p.equals("/")) p = "/index.html";
      Path f = Paths.get("public", p).normalize();
      if (!f.startsWith("public") || !Files.exists(f)) { ex.sendResponseHeaders(404, -1); ex.close(); return; }
      String t = p.endsWith(".css") ? "text/css" : p.endsWith(".js") ? "application/javascript" : "text/html";
      byte[] b = Files.readAllBytes(f);
      ex.getResponseHeaders().add("Content-Type", t + "; charset=utf-8");
      ex.sendResponseHeaders(200, b.length); try (OutputStream o = ex.getResponseBody()) { o.write(b); } ex.close();
    });
    s.start(); System.out.println("SkyTrip rodando em http://localhost:" + port);
  }
}
