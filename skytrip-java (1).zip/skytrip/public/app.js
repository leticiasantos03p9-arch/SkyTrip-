let viagens=JSON.parse(localStorage.getItem('skytrip')||'[]'),tela='inicio';
const brl=n=>n.toLocaleString('pt-BR',{style:'currency',currency:'BRL'}),uid=()=>Math.random().toString(36).slice(2);
fetch('/api/viagens').then(r=>r.json()).then(d=>{if(d.length){viagens=d;render()}}).catch(()=>{});
function salvar(){localStorage.setItem('skytrip',JSON.stringify(viagens));fetch('/api/viagens',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(viagens)}).catch(()=>{});render()}
const tot=v=>v.gastos.reduce((a,g)=>a+g.valor,0),esc=s=>String(s).replace(/[&<>"]/g,c=>'&#'+c.charCodeAt(0)+';');
function ir(t){tela=t;render()}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>ir(b.dataset.t));
function render(){const a=document.getElementById('app');
document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.t===tela));
if(tela==='inicio')a.innerHTML=`<div class=card><p class=muted>Viagens planejadas</p><p class=big>${viagens.length}</p><p class=muted>Total de gastos</p><h2>${brl(viagens.reduce((s,v)=>s+tot(v),0))}</h2></div><button class=btn onclick="ir('nova')">+ Nova viagem</button>`;
else if(tela==='viagens')a.innerHTML=viagens.length?viagens.map(v=>`<div class="card trip"><div onclick="ir('${v.id}')"><b>📍 ${esc(v.destino)}</b><div class=muted>${v.inicio} → ${v.fim} · ${v.viajantes} viajante(s)</div></div><button class=x onclick="excluir('${v.id}')">🗑️</button></div>`).join(''):'<p class=muted style="text-align:center">Nenhuma viagem ainda.</p>';
else if(tela==='nova')a.innerHTML=`<form class=card onsubmit="criar(event)"><h2>Nova viagem</h2><input id=d placeholder=Destino required><div class=row><input id=i type=date><input id=f type=date></div><input id=n type=number min=1 value=1><button class=btn style="width:100%">Salvar viagem</button></form>`;
else{const v=viagens.find(x=>x.id===tela);if(!v)return ir('viagens');
a.innerHTML=`<div class=card><h2>📍 ${esc(v.destino)}</h2><p class=muted>🗓️ ${v.inicio} → ${v.fim} · 👥 ${v.viajantes}</p></div>
<div class=card><h3>🗓️ Roteiro</h3>${v.roteiro.map(r=>`<div class=item>${esc(r.texto)}<button class=x onclick="rmAt('${r.id}')">✕</button></div>`).join('')}<div class=row><input id=at placeholder="Nova atividade"><button class=btn onclick="addAt()">+</button></div></div>
<div class=card><h3>💳 Gastos</h3>${v.gastos.map(g=>`<div class=item>${esc(g.desc)}<span>${brl(g.valor)} <button class=x onclick="rmG('${g.id}')">✕</button></span></div>`).join('')}<div class=row><input id=gd placeholder=Descrição><input id=gv type=number placeholder=R$ style="width:100px"><button class=btn onclick="addG()">+</button></div><p class=total>Total: ${brl(tot(v))}</p><p class=muted style="text-align:right">Por pessoa: ${brl(tot(v)/(v.viajantes||1))}</p></div>`}}
const cur=()=>viagens.find(x=>x.id===tela);
function criar(e){e.preventDefault();const v={id:uid(),destino:d.value,inicio:i.value,fim:f.value,viajantes:+n.value||1,roteiro:[],gastos:[]};viagens.push(v);tela=v.id;salvar()}
function excluir(id){if(confirm('Excluir viagem?')){viagens=viagens.filter(v=>v.id!==id);salvar()}}
function addAt(){const t=document.getElementById('at').value;if(t){cur().roteiro.push({id:uid(),texto:t});salvar()}}
function rmAt(id){const v=cur();v.roteiro=v.roteiro.filter(r=>r.id!==id);salvar()}
function addG(){const d=gd.value,val=+gv.value;if(d&&val){cur().gastos.push({id:uid(),desc:d,valor:val});salvar()}}
function rmG(id){const v=cur();v.gastos=v.gastos.filter(g=>g.id!==id);salvar()}
render();
